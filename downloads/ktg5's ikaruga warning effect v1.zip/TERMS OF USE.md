# Hi, ktg5 made this.

## YOU MAY:
* Use this pack for personal / funny reasons (YouTube videos, school projects, etc.).
* Edit whatever you'd like to within the pack!

## YOU MAY NOT:
* Repost / re-sell this pack without permission.
* Use this pack for monetary use / gain (This does not affect YouTube videos, mainly just advertisements and such).

### (c) ktg5.online 2023